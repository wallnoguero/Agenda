export default{
    cartaoElevacaoSombra: 8
}