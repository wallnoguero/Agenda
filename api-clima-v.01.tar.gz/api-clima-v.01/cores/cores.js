export default {
    accent: '#d9d9d9',
    primary: '#2196F3',
    black: '#000'
}