export default{
    LembreteInputColor: 'black'
}