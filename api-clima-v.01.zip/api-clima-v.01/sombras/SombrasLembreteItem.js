export default{
    LembreteBordarCor: 'black'
}